﻿"use client";
import React, { useState } from "react";
import { useLanguage } from "@/context/LanguageContext";

export default function VideoGenerator() {
  const [prompt, setPrompt] = useState("");
  const { language } = useLanguage();

  return (
    <div className="w-full max-w-4xl mx-auto p-4">
      <textarea
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder={language === "ar" ? "ضع إبداعك هنا..." : "Put your creativity here..."}
        className="w-full h-48 bg-[#080808] border border-white/5 rounded-3xl p-8 text-white outline-none focus:border-purple-500/50 transition-all resize-none shadow-inner"
      />
    </div>
  );
}
